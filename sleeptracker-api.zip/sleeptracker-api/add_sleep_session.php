<?php
header("Content-Type: application/json");

// Read raw POST data
$rawData = file_get_contents("php://input");
file_put_contents("debug_log.txt", "RAW: $rawData" . PHP_EOL, FILE_APPEND); // Log raw data

$data = json_decode($rawData, true); // Decode into associative array

if (!$data || !isset($data['user_id'], $data['start'], $data['stop'], $data['events'])) {
    echo json_encode([
        "success" => false,
        "error" => "Invalid or missing fields",
        "received" => $data
    ]);
    exit;
}

$userId = $data['user_id']; // updated key
$start  = $data['start'];
$stop   = $data['stop'];
$events = $data['events'];

try {
    $pdo = new PDO("mysql:host=localhost;dbname=sleep", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable error reporting

    $stmt = $pdo->prepare("INSERT INTO sleep_sessions (user_id, start, stop, events) VALUES (?, ?, ?, ?)");
    $stmt->execute([$userId, $start, $stop, $events]);

    echo json_encode([
        "success" => true,
        "message" => "Session inserted",
        "received" => $data
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage(),
        "received" => $data
    ]);
}
