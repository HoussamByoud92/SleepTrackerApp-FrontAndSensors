<?php
require 'db.php';
$user_id = $_GET['user_id'];

$stmt = $conn->prepare("SELECT * FROM sleep_sessions WHERE user_id = ? ORDER BY start DESC");
$stmt->execute([$user_id]);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($sessions);
?>
