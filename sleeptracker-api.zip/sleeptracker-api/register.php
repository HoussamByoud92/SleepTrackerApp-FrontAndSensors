<?php
require 'db.php';
header("Content-Type: application/json");

// Get raw input and decode JSON
$data = json_decode(file_get_contents("php://input"));

if (!$data || !isset($data->username, $data->email, $data->password)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid input"]);
    exit;
}

$username = trim($data->username);
$email = trim($data->email);
$password = password_hash($data->password, PASSWORD_DEFAULT);

// Prepare and execute insert
$stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");

if ($stmt->execute([$username, $email, $password])) {
    http_response_code(201);
    echo json_encode(["success" => true, "message" => "User registered successfully"]);
} else {
    http_response_code(409); // Conflict (e.g., duplicate email)
    echo json_encode(["success" => false, "message" => "Registration failed. Email may already exist."]);
}
?>
